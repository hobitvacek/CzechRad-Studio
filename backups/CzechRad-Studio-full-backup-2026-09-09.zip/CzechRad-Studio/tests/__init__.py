"""Tests for CzechRad Studio."""
