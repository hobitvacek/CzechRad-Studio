"""Minimal QGIS plugin shell.

Copyright (C) 2026 CzechRad Studio contributors
SPDX-License-Identifier: GPL-3.0-or-later
"""

from pathlib import Path

from qgis.PyQt.QtCore import QSettings, QTimer
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsGeometry,
    QgsMarkerSymbol,
    QgsPointXY,
    QgsProject,
    QgsVectorLayer,
)
from qgis.gui import QgsMapToolEmitPoint

from .core.constants import PLUGIN_NAME
from .database import GeoPackageRepository, ImportDisposition
from .importer import analyze_log_files
from .missions import assess_stop_radiation
from .monitoring import StableFileTracker, archive_ready_logs
from .qt_compat import QAction, DIALOG_ACCEPTED, exec_dialog
from .ui import (
    ImportDialog,
    ManualSegmentDialog,
    MonitorDialog,
    ProjectDialog,
    SavedSegmentsDialog,
    SegmentsDialog,
    add_analysis_layers,
)


MAX_MAP_SNAP_DISTANCE_M = 500.0


class CzechRadStudioPlugin:
    """Register and remove the initial CzechRad Studio UI action."""

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.project_action = None
        self.monitor_action = None
        self.segments_action = None
        self.saved_segments_action = None
        self.monitor_timer = QTimer(self.iface.mainWindow())
        self.monitor_timer.setInterval(5000)
        self.monitor_timer.timeout.connect(self._poll_monitor)
        self.monitor_tracker = StableFileTracker()
        self._monitored_archives = {}
        self._monitored_layers = {}
        self._loaded_digests = set()
        self._latest_nogps = None
        self._proposal_focus_layer = None
        self._segments_dialog = None
        self._saved_segments_dialog = None
        self._map_segment_tool = None
        self._previous_map_tool = None
        self._map_segment_selection = None
        self._map_boundary_layers = []

    def initGui(self):  # noqa: N802 - QGIS requires this name
        self.action = QAction(PLUGIN_NAME, self.iface.mainWindow())
        self.action.setObjectName("czechradStudioOpenAction")
        self.action.setStatusTip("Otevřít CzechRad Studio")
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu(f"&{PLUGIN_NAME}", self.action)
        self.iface.addToolBarIcon(self.action)

        self.project_action = QAction(
            "Projekt a aktivní mise…", self.iface.mainWindow()
        )
        self.project_action.triggered.connect(self.configure_project)
        self.iface.addPluginToMenu(f"&{PLUGIN_NAME}", self.project_action)

        self.monitor_action = QAction(
            "Nastavit automatický import…", self.iface.mainWindow()
        )
        self.monitor_action.triggered.connect(self.configure_monitoring)
        self.iface.addPluginToMenu(f"&{PLUGIN_NAME}", self.monitor_action)

        self.segments_action = QAction(
            "Měřicí úseky…", self.iface.mainWindow()
        )
        self.segments_action.triggered.connect(self.review_segments)
        self.iface.addPluginToMenu(f"&{PLUGIN_NAME}", self.segments_action)

        self.saved_segments_action = QAction(
            "Uložené úseky…", self.iface.mainWindow()
        )
        self.saved_segments_action.triggered.connect(self.review_saved_segments)
        self.iface.addPluginToMenu(
            f"&{PLUGIN_NAME}", self.saved_segments_action
        )
        self._apply_monitor_settings()

    def unload(self):
        if self.action is None:
            return

        self.monitor_timer.stop()
        self._cancel_map_segment_selection()
        self._remove_proposal_focus_layer()
        if self._segments_dialog is not None:
            self._segments_dialog.close()
            self._segments_dialog.deleteLater()
            self._segments_dialog = None
        if self._saved_segments_dialog is not None:
            self._saved_segments_dialog.close()
            self._saved_segments_dialog.deleteLater()
            self._saved_segments_dialog = None
        if self.project_action is not None:
            self.iface.removePluginMenu(f"&{PLUGIN_NAME}", self.project_action)
            self.project_action.deleteLater()
            self.project_action = None
        if self.monitor_action is not None:
            self.iface.removePluginMenu(f"&{PLUGIN_NAME}", self.monitor_action)
            self.monitor_action.deleteLater()
            self.monitor_action = None
        if self.segments_action is not None:
            self.iface.removePluginMenu(f"&{PLUGIN_NAME}", self.segments_action)
            self.segments_action.deleteLater()
            self.segments_action = None
        if self.saved_segments_action is not None:
            self.iface.removePluginMenu(
                f"&{PLUGIN_NAME}", self.saved_segments_action
            )
            self.saved_segments_action.deleteLater()
            self.saved_segments_action = None

        self.iface.removePluginMenu(f"&{PLUGIN_NAME}", self.action)
        self.iface.removeToolBarIcon(self.action)
        self.action.deleteLater()
        self.action = None

    def configure_monitoring(self):
        dialog = MonitorDialog(self.iface.mainWindow())
        if exec_dialog(dialog) == DIALOG_ACCEPTED:
            self.monitor_tracker = StableFileTracker()
            self._apply_monitor_settings()

    def configure_project(self):
        dialog = ProjectDialog(self.iface.mainWindow())
        if exec_dialog(dialog) == DIALOG_ACCEPTED:
            repository = GeoPackageRepository(dialog.database_path)
            mission = repository.get_mission(dialog.mission_id)
            self.iface.messageBar().pushSuccess(
                PLUGIN_NAME, f"Aktivní mise: {mission.name}"
            )

    def review_segments(self):
        database_path, mission_id = ProjectDialog.active_configuration()
        if not database_path or not mission_id:
            QMessageBox.information(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                "Nejprve vyber projektový GeoPackage a aktivní misi v nabídce "
                "„Projekt a aktivní mise…“.",
            )
            return
        if self._segments_dialog is not None:
            self._segments_dialog.show()
            self._segments_dialog.raise_()
            self._segments_dialog.activateWindow()
            return
        self._segments_dialog = SegmentsDialog(
            database_path, mission_id, self.iface.mainWindow()
        )
        self._segments_dialog.proposal_focus_requested.connect(
            lambda proposal: self._focus_segment_proposal(
                database_path, proposal
            )
        )
        self._segments_dialog.finished.connect(self._segments_dialog_finished)
        self._segments_dialog.show()

    def _segments_dialog_finished(self, _result):
        if self._segments_dialog is not None:
            self._segments_dialog.deleteLater()
            self._segments_dialog = None

    def review_saved_segments(self):
        database_path, mission_id = ProjectDialog.active_configuration()
        if not database_path or not mission_id:
            QMessageBox.information(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                "Nejprve vyber projektový GeoPackage a aktivní misi v nabídce "
                "„Projekt a aktivní mise…“.",
            )
            return
        if self._saved_segments_dialog is not None:
            self._saved_segments_dialog.show()
            self._saved_segments_dialog.raise_()
            self._saved_segments_dialog.activateWindow()
            return
        self._saved_segments_dialog = SavedSegmentsDialog(
            database_path, mission_id, self.iface.mainWindow()
        )
        self._saved_segments_dialog.segment_focus_requested.connect(
            lambda segment: self._focus_saved_segment(database_path, segment)
        )
        self._saved_segments_dialog.map_segment_requested.connect(
            lambda: self._begin_map_segment_selection(
                database_path, mission_id
            )
        )
        self._saved_segments_dialog.unassigned_focus_requested.connect(
            lambda: self._focus_unassigned_measurements(
                database_path, mission_id
            )
        )
        self._saved_segments_dialog.finished.connect(
            self._saved_segments_dialog_finished
        )
        self._saved_segments_dialog.show()

    def _saved_segments_dialog_finished(self, _result):
        self._cancel_map_segment_selection()
        if self._saved_segments_dialog is not None:
            self._saved_segments_dialog.deleteLater()
            self._saved_segments_dialog = None

    def _remove_map_boundary_layers(self):
        project = QgsProject.instance()
        for layer in self._map_boundary_layers:
            project.removeMapLayer(layer.id())
        self._map_boundary_layers = []

    def _restore_previous_map_tool(self):
        if self._map_segment_tool is None:
            return
        canvas = self.iface.mapCanvas()
        if self._previous_map_tool is not None:
            canvas.setMapTool(self._previous_map_tool)
        else:
            canvas.unsetMapTool(self._map_segment_tool)
        self._map_segment_tool = None
        self._previous_map_tool = None

    def _cancel_map_segment_selection(self):
        self._restore_previous_map_tool()
        self._map_segment_selection = None
        self._remove_map_boundary_layers()

    def _begin_map_segment_selection(self, database_path, mission_id):
        self._cancel_map_segment_selection()
        repository = GeoPackageRepository(database_path)
        if not repository.list_mission_recordings(mission_id):
            QMessageBox.information(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                "Aktivní mise nemá žádné načtené měření.",
            )
            return
        canvas = self.iface.mapCanvas()
        self._previous_map_tool = canvas.mapTool()
        self._map_segment_tool = QgsMapToolEmitPoint(canvas)
        self._map_segment_tool.canvasClicked.connect(
            self._map_boundary_clicked
        )
        self._map_segment_selection = {
            "database_path": database_path,
            "mission_id": mission_id,
            "repository": repository,
            "first": None,
        }
        canvas.setMapTool(self._map_segment_tool)
        canvas.setFocus()
        self.iface.messageBar().pushInfo(
            PLUGIN_NAME,
            "Klikni v mapě na první bod úseku. Výběr se připne k "
            "nejbližšímu platnému měření.",
        )

    def _map_point_wgs84(self, point):
        canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        transform = QgsCoordinateTransform(
            canvas_crs,
            QgsCoordinateReferenceSystem("EPSG:4326"),
            QgsProject.instance(),
        )
        return transform.transform(point)

    def _add_boundary_marker(self, measurement, *, first):
        label = "začátek" if first else "konec"
        color = "0,170,70,240" if first else "220,45,45,240"
        layer = QgsVectorLayer(
            "Point?crs=EPSG:4326",
            f"CzechRad – {label} úseku",
            "memory",
        )
        feature = QgsFeature()
        feature.setGeometry(
            QgsGeometry.fromPointXY(
                QgsPointXY(measurement.longitude, measurement.latitude)
            )
        )
        layer.dataProvider().addFeature(feature)
        layer.updateExtents()
        layer.renderer().setSymbol(
            QgsMarkerSymbol.createSimple(
                {
                    "name": "circle",
                    "color": color,
                    "size": "5.0",
                    "outline_color": "255,255,255,255",
                    "outline_width": "0.8",
                }
            )
        )
        QgsProject.instance().addMapLayer(layer)
        layer.triggerRepaint()
        self._map_boundary_layers.append(layer)

    def _map_boundary_clicked(self, point, _button):
        selection = self._map_segment_selection
        if selection is None:
            return
        try:
            wgs84 = self._map_point_wgs84(point)
            first = selection["first"]
            nearest = selection["repository"].nearest_mission_measurement(
                selection["mission_id"],
                wgs84.x(),
                wgs84.y(),
                recording_id=(
                    None if first is None else first.recording_id
                ),
            )
        except Exception as exc:
            self.iface.messageBar().pushWarning(PLUGIN_NAME, str(exc))
            return
        if nearest.distance_m > MAX_MAP_SNAP_DISTANCE_M:
            self.iface.messageBar().pushWarning(
                PLUGIN_NAME,
                f"Nejbližší bod je vzdálen {nearest.distance_m:.0f} m. "
                "Přibliž mapu a klikni blíže k trase.",
            )
            return
        if first is None:
            selection["first"] = nearest
            self._add_boundary_marker(nearest, first=True)
            self.iface.messageBar().pushInfo(
                PLUGIN_NAME,
                f"Začátek: {nearest.measured_at:%H:%M:%S} UTC, "
                f"{nearest.source_name}. Nyní klikni na konec úseku.",
            )
            return

        self._add_boundary_marker(nearest, first=False)
        self._complete_map_segment_selection(first, nearest)

    def _complete_map_segment_selection(self, first, second):
        selection = self._map_segment_selection
        if selection is None:
            return
        self._restore_previous_map_tool()
        start = min(first.measured_at, second.measured_at)
        end = max(first.measured_at, second.measured_at)
        dialog = ManualSegmentDialog(
            selection["database_path"],
            selection["mission_id"],
            self.iface.mainWindow(),
            initial_recording_id=first.recording_id,
            initial_start=start,
            initial_end=end,
        )
        if exec_dialog(dialog) == DIALOG_ACCEPTED:
            segment = dialog.created_segment
            if self._saved_segments_dialog is not None:
                self._saved_segments_dialog.add_created_segment(segment)
        self._map_segment_selection = None
        self._remove_map_boundary_layers()

    def _remove_proposal_focus_layer(self):
        if self._proposal_focus_layer is None:
            return
        QgsProject.instance().removeMapLayer(self._proposal_focus_layer.id())
        self._proposal_focus_layer = None

    def _focus_segment_proposal(self, database_path, proposal):
        repository = GeoPackageRepository(database_path)
        positions = repository.list_proposal_positions(proposal.id)
        if not positions and proposal.center_longitude is not None:
            positions = ((proposal.center_longitude, proposal.center_latitude),)
        if not positions:
            QMessageBox.information(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                "Návrh nemá použitelnou polohu pro zobrazení v mapě.",
            )
            return

        self._show_focus_positions(
            positions,
            "CzechRad – vybraný návrh",
            "Vybraný návrh je v mapě zvýrazněn fialově.",
        )

    def _focus_saved_segment(self, database_path, segment):
        positions = GeoPackageRepository(database_path).list_segment_positions(
            segment.id
        )
        if not positions:
            QMessageBox.information(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                "Uložený úsek nemá použitelnou polohu pro zobrazení v mapě.",
            )
            return
        self._show_focus_positions(
            positions,
            "CzechRad – uložený úsek",
            "Uložený úsek je v mapě zvýrazněn fialově.",
        )

    def _focus_unassigned_measurements(self, database_path, mission_id):
        summary = GeoPackageRepository(
            database_path
        ).unassigned_mission_measurements(mission_id)
        if summary.total_count == 0:
            QMessageBox.information(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                "Aktivní mise zatím neobsahuje žádná měření.",
            )
            return
        if summary.unassigned_count == 0:
            self._remove_proposal_focus_layer()
            self.iface.messageBar().pushSuccess(
                PLUGIN_NAME,
                "Všechna aktuální měření jsou již zařazena do úseků.",
            )
            return
        if not summary.positions:
            QMessageBox.information(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                f"Nezařazených měření: {summary.unassigned_count}. Žádné z "
                "nich ale nemá platnou polohu pro zobrazení v mapě.",
            )
            return
        self._show_focus_positions(
            summary.positions,
            "CzechRad – nezařazená data",
            f"Modře je zvýrazněno {summary.mapped_count} bodů. "
            f"Celkem nezařazených měření: {summary.unassigned_count} "
            f"z {summary.total_count}.",
            color="0,120,255,215",
            size="3.2",
        )

    def _show_focus_positions(
        self,
        positions,
        layer_name,
        success_message,
        *,
        color="210,0,255,210",
        size="4.0",
    ):
        self._remove_proposal_focus_layer()
        layer = QgsVectorLayer(
            "Point?crs=EPSG:4326", layer_name, "memory"
        )
        features = []
        for longitude, latitude in positions:
            feature = QgsFeature()
            feature.setGeometry(
                QgsGeometry.fromPointXY(QgsPointXY(longitude, latitude))
            )
            features.append(feature)
        layer.dataProvider().addFeatures(features)
        layer.updateExtents()
        symbol = QgsMarkerSymbol.createSimple(
            {
                "name": "circle",
                "color": color,
                "size": size,
                "outline_color": "255,255,255,255",
                "outline_width": "0.6",
            }
        )
        layer.renderer().setSymbol(symbol)
        layer.triggerRepaint()
        QgsProject.instance().addMapLayer(layer)
        self._proposal_focus_layer = layer
        self.iface.setActiveLayer(layer)
        self.iface.zoomToActiveLayer()
        if self.iface.mapCanvas().scale() < 2500:
            self.iface.mapCanvas().zoomScale(2500)
        self.iface.mapCanvas().refresh()
        self.iface.mapCanvas().setFocus()
        self.iface.messageBar().pushSuccess(
            PLUGIN_NAME,
            success_message,
        )

    @staticmethod
    def _store_analysis(analysis, track_path, nogps_path=None):
        database_path, mission_id = ProjectDialog.active_configuration()
        if not database_path or not mission_id:
            return None
        repository = GeoPackageRepository(database_path)
        return repository.store_import(
            analysis,
            track_path,
            nogps_path=nogps_path,
            mission_id=mission_id,
        )

    def _apply_monitor_settings(self):
        enabled = QSettings().value(MonitorDialog.ENABLED_KEY, False, type=bool)
        if enabled:
            self.monitor_timer.start()
        else:
            self.monitor_timer.stop()

    @staticmethod
    def _is_nogps(path: Path) -> bool:
        return path.stem.upper().startswith("NOGPS")

    def _replace_monitored_layer(self, source_key: str, track_path: Path):
        analysis = analyze_log_files(track_path, self._latest_nogps)
        self._store_analysis(analysis, track_path, self._latest_nogps)
        new_layers = add_analysis_layers(
            analysis,
            str(track_path),
            collapse_stops=True,
            display_unit="device_usvh",
        )
        previous = self._monitored_layers.get(source_key)
        self._monitored_layers[source_key] = new_layers
        self._monitored_archives[source_key] = track_path
        if previous is not None:
            project = QgsProject.instance()
            project.removeMapLayer(previous.track.id())
            if previous.candidates is not None:
                project.removeMapLayer(previous.candidates.id())

    def _poll_monitor(self):
        settings = QSettings()
        source = settings.value(MonitorDialog.SOURCE_KEY, "", type=str)
        archive = settings.value(MonitorDialog.ARCHIVE_KEY, "", type=str)
        if not source or not archive or not Path(source).is_dir():
            return
        try:
            results = archive_ready_logs(self.monitor_tracker, source, archive)
            nogps_results = [
                result for result in results if self._is_nogps(result.destination)
            ]
            if nogps_results:
                self._latest_nogps = nogps_results[-1].destination

            daily_results = [
                result
                for result in results
                if not self._is_nogps(result.destination)
                and result.digest not in self._loaded_digests
            ]
            for result in daily_results:
                self._replace_monitored_layer(
                    str(result.source).casefold(), result.destination
                )
                self._loaded_digests.add(result.digest)

            if nogps_results:
                for source_key, track_path in tuple(self._monitored_archives.items()):
                    self._replace_monitored_layer(source_key, track_path)

            copied_count = sum(result.copied for result in results)
            if copied_count:
                self.iface.messageBar().pushSuccess(
                    PLUGIN_NAME,
                    f"Archivováno {copied_count} nových nebo změněných LOGů.",
                )
        except Exception as exc:
            self.iface.messageBar().pushWarning(
                PLUGIN_NAME, f"Automatický import se nezdařil: {exc}"
            )

    def run(self):
        dialog = ImportDialog(self.iface.mainWindow())
        if exec_dialog(dialog) != DIALOG_ACCEPTED:
            return

        try:
            analysis = analyze_log_files(dialog.track_path, dialog.nogps_path)
            stored = self._store_analysis(
                analysis, dialog.track_path, dialog.nogps_path
            )
            layers = add_analysis_layers(
                analysis,
                dialog.track_path,
                collapse_stops=dialog.collapse_stops,
                display_unit=dialog.display_unit,
            )
            self.iface.setActiveLayer(layers.track)
            # QGIS transforms the layer's WGS 84 extent to the canvas CRS
            # (commonly Web Mercator for the OpenStreetMap template).
            self.iface.zoomToActiveLayer()
        except Exception as exc:  # QGIS must report file and provider failures to user
            QMessageBox.critical(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                f"Měření se nepodařilo načíst:\n\n{exc}",
            )
            return

        correlation = analysis.nogps_correlation
        matched_nogps = len(correlation.matched) if correlation is not None else 0
        elevated_stops = sum(
            assessment is not None and assessment.elevated
            for assessment in (
                assess_stop_radiation(candidate, analysis.geometry_measurements)
                for candidate in analysis.stop_candidates
            )
        )
        database_message = ""
        if stored is not None:
            disposition_labels = {
                ImportDisposition.CREATED: "nové samostatné měření uloženo",
                ImportDisposition.REVISED: "uložena nová revize měření",
                ImportDisposition.UNCHANGED: "databáze beze změny",
            }
            database_message = (
                f"\nDatabáze: {disposition_labels[stored.disposition]} "
                f"({stored.measurement_count} měření)"
                f"\nPořadí měření v daném dni: {stored.recording_sequence}"
                f"\nAutomatické návrhy úseků: {stored.proposal_count}"
            )
        QMessageBox.information(
            self.iface.mainWindow(),
            PLUGIN_NAME,
            "Měření bylo načteno.\n\n"
            f"Přístroj: {analysis.track.measurements[0].device_family} "
            f"({analysis.track.measurements[0].device_type}, "
            f"č. {analysis.track.measurements[0].device_id})\n"
            f"Datum (UTC): {analysis.expected_date.isoformat()}\n"
            f"Záznamů v denním LOGu: {len(analysis.track.measurements)}\n"
            f"Bodů v mapě: {len(analysis.geometry_measurements)}\n"
            f"Přiřazených NOGPS záznamů: {matched_nogps}\n"
            f"Kandidátů zastavení: {len(analysis.stop_candidates)}\n"
            f"Možných stacionárních měření: {elevated_stops}\n"
            f"Kandidátů ztráty GPS: {len(analysis.location_losses)}\n"
            f"Nezpracovaných řádků: {analysis.failure_count}"
            f"{database_message}",
        )
